
#include <iostream>
#include <random>

int SayPlayerGreeting()
{
	std::cout << "Welcome to the Casino, friend! \n" 
			<< "If you guess the sum of my 2 dice then you win! \n" << std::endl;
	return 0;
}

int SayBye()
{
	std::cout << "Goodbye friend, and  good luck!" << std::endl;
	return 0;
}
int SayInputError()
{
	std::cout << "wrong input! \n"
		<< "Give me another guess " << std::endl;
	return 0;
}

int SayPlayAgain()
{
	std::cout << "Want to play again? Y or N?" << std::endl;
	return 0;
}

int GameGuessSum(int aPlayerValue, int aDie1, int aDie2)
{
	int die1;
	int die2;
	int DiceSum;
	die1 = aDie1;
	die2 = aDie2;
	DiceSum = die1 + die2;
	std::cout << "I rolled: " << die1 << " and " << die2 << '\n'
		<< "Sum: " << die1 + die2 << '\n' << std::endl;
	if (aPlayerValue != DiceSum)
	{
		std::cout << "Thats wrong, you unlucky fool! \n" << std::endl;
	}
	else
	{
		std::cout << "You guessed correct!" << std::endl;
	}
	return 0;
}

int UpdatePlayerGuess() {
	bool isUpdateActive = true;
	int playerNumberGuess = 0;
	int returnValue;

	std::cout << "The table is open! So give me one between 2 and 12! Lets gamble!" << std::endl;

	while (isUpdateActive == true)
	{
		std::cin >> playerNumberGuess;

		if (std::cin.fail())
		{
			std::cin.clear();
			std::cin.ignore(1000, '\n');
			SayInputError();
		}
		else if (playerNumberGuess < 2 || playerNumberGuess >12)
			{
				SayInputError();
			}
			else
			{
				std::cout << "You picked: " << playerNumberGuess << std::endl;
				isUpdateActive = false;
			}
	}

	return returnValue = playerNumberGuess;
}

bool QueryReplay() {
	char playerInput;
	bool isQueryActive = true;

	while (isQueryActive == true)
	{
		SayPlayAgain();
		std::cin >> playerInput;
		if (std::cin.fail())
		{
			std::cin.clear();
			std::cin.ignore(1000, '\n');
			SayInputError();
		}
		else {
			if (playerInput == 'Y' || playerInput == 'y')
			{
				isQueryActive = false;
				return true;
			}
			else if (playerInput == 'N' || playerInput == 'n')
			{
				isQueryActive = false;
				return false;
			}
			else
			{
				SayInputError();
			}
		}
	}

	return 0;
}

int StartGame()
{
	std::cout << "the game has begun!!" << std::endl;
	return 0;
}
int main()
{
	std::random_device seed;
	std::mt19937 rndEngine(seed());
	std::uniform_int_distribution<int> rndDist(1, 6);
	int randNumber = rndDist(rndEngine);

	bool isGameActive = true;

	SayPlayerGreeting();
	while (isGameActive == true)
	{
		StartGame();
		GameGuessSum(UpdatePlayerGuess(), randNumber, randNumber);
		isGameActive = QueryReplay();
	}

	SayBye();
}